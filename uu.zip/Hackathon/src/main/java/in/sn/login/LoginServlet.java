package in.sn.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/lgform")

public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter out=resp.getWriter();
		
        //String myname1=req.getParameter("name2");
        String myemail1=req.getParameter("email2");
        String mypassword1=req.getParameter("password2");
        
        try {
			
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/heck","root","123456");
        	PreparedStatement ps=con.prepareStatement("select * from hacks where  email=? and password=?");
        	//ps.setString(1, myname1);
        	ps.setString(1, myemail1);
        	ps.setString(2, mypassword1);
        	
        	ResultSet rs =ps.executeQuery();
        	
        	if(rs.next()) {
        		
        		HttpSession session=req.getSession();
        		session.setAttribute("session_name", rs.getString("name"));
        		
        		RequestDispatcher rd=req.getRequestDispatcher("/welcome.jsp");
        		rd.include(req, resp);
        		
        	}
        	
        	else {
        		
        		resp.setContentType("text/html");
        		out.print("<h3 style='color:blue'>User Email or Password is Incorret</h3>");
				RequestDispatcher rd=req.getRequestDispatcher("/login.jsp");
				rd.include(req, resp);
			}
        	
		} catch (Exception e) {
			e.printStackTrace();
			resp.setContentType("text/html");
    		out.print("<h3 style='color:blue'>Exception Occured:"+e.getMessage()+"</h3>");
			RequestDispatcher rd=req.getRequestDispatcher("/login.jsp");
			rd.include(req, resp);
		}
		
	}
	
}
